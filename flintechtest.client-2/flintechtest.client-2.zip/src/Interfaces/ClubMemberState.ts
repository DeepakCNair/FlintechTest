import { ClubMember } from "./ClubMember";

export interface ClubMemberState {
    clubMembers: ClubMember[]
}