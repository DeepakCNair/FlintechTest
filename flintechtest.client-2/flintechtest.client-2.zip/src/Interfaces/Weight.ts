export interface Weight {
    imperial: string;
    metric: string;
  }