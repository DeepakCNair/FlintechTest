﻿namespace FlintechTest.Server.Models
{
    public class AppSettings
    {
        public int? PaginationLimitPerPage { get; set; }
    }
}
