﻿namespace FlintechTest.Server.Models
{
    public class Weight
    {
        public string imperial { get; set; }
        public string metric { get; set; }
    }
}
